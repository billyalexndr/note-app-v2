import React from "react";

const NotFoundPage = () => {
    return <div className="not-found">Halaman tidak ditemukan.</div>;
};

export default NotFoundPage;
